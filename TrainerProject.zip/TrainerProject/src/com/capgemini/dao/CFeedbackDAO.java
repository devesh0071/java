package com.capgemini.dao;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.util.DBUtil;

public class CFeedbackDAO implements FeedbackDAO{

	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		int FeedbackId= (int) (Math.random()*1000);
		DBUtil.feedbackList.put(FeedbackId,trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		// TODO Auto-generated method stub
	
		return DBUtil.feedbackList;
	}
	
	

	

}
