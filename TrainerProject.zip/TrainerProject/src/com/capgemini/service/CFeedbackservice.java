package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.CFeedbackDAO;
import com.capgemini.dao.FeedbackDAO;

public class CFeedbackservice implements Feedbackservice{

	FeedbackDAO daoref=new CFeedbackDAO();
	
	public CFeedbackservice() {
		
	}
	
	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		daoref.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		// TODO Auto-generated method stub
		return daoref.getTrainerList();
	}

}
