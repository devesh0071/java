package com.capgemini.bean;

import java.util.Scanner;

import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class main {

	public static void main(String[] args) {
		
		FeedbackService s=new FeedbackServiceImpl();
        String name,courseName,Bdate,Edate;
        int feedback;
        Scanner sc = new Scanner(System.in);
        name = sc.nextLine();
        courseName = sc.nextLine();
        Bdate = sc.nextLine();
        Edate = sc.nextLine();
        feedback = sc.nextInt();
        
        Trainer pr = new Trainer(name,courseName,Bdate,Edate,feedback);
        s.addFeedback(pr);

	}

}
