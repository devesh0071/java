package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.DAO.FeedbackDAO;
import com.capgemini.DAO.FeedbackDAOImpl;
import com.capgemini.bean.Trainer;


public class FeedbackServiceImpl implements FeedbackService {

	private FeedbackDAO daoRef = new FeedbackDAOImpl();
	@Override
	public void addFeedback(Trainer trainer) {
		daoRef.addFeedback(trainer);
		
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		
		return daoRef.getTrainerList();
	}

	
}
