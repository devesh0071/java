package com.capgemini.DAO;

import java.util.HashMap;
import java.util.Random;

import com.capgemini.bean.Trainer;
import com.capgemini.util.DBUtil;

public class FeedbackDAOImpl implements FeedbackDAO {
	HashMap<Integer, Trainer> ht = new HashMap<>();
	public FeedbackDAOImpl()
	{
		ht = DBUtil.feedbackList;
	}

	@Override
	public void addFeedback(Trainer trainer) {
		
		Random rand = new Random(); 
		int rand_int1 = rand.nextInt(1000); 
	    ht.put(rand_int1,trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		
		return ht;
 		
	}
	
	
    
}
