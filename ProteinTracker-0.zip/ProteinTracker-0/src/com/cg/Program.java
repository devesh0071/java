package com.cg;

import org.hibernate.Session;

public class Program {
	
	public static void main(String[] args) {
		System.out.println("Hello world");
		Session session = HibernateUtilities.getSessionFactory().openSession();
		
		session.beginTransaction();
		User user=new User();
		user.setName("Akshay");
		user.setGoal(250);
		user.setTotal(100);
		
		session.save(user);
		session.getTransaction().commit();
		
		System.out.println(user.getName());
		System.out.println(user.getGoal());
		System.out.println(user.getTotal());
		//System.out.println("Session started: "+ session.isConnected());
		
		//System.out.println(session.getSessionFactory());
		session.close();
		HibernateUtilities.getSessionFactory().close();
	}
}
