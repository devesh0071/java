package com.baeldung.scope.singletone;

import java.time.LocalTime;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;

import com.baeldung.scope.prototype.PrototypeBean;

public class SingletonBean {

    private final Logger logger = Logger.getAnonymousLogger();

    @Autowired
    private PrototypeBean prototypeBean;

    public SingletonBean() {
        logger.info("Singleton instance created");
    }

    public PrototypeBean getPrototypeBean() {
        logger.info(String.valueOf(LocalTime.now()));
        return prototypeBean;
    }
    
   /* @Lookup
    public PrototypeBean getPrototypeBean() {
        return null;
    }*/
    
    
    
}