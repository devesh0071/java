package com.cg.main;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.beans.Trainer;
import com.cg.service.FeedbackService;
import com.cg.service.Feedbackserviceimpl;

public class TrainerMain {
	private static Scanner sc;
	
	/*FeedbackService service = new Feedbackserviceimpl();*/
	
	
	public static void main(String[] args) {
		FeedbackService service = new Feedbackserviceimpl();
		Map<Integer,Trainer> maps= new HashMap<Integer,Trainer>();
		String name;
		String coursename;
		String startdate;
		String enddate;
		int rating;
		sc = new Scanner(System.in);
		
		System.out.println("Enter trainer name ");
		name=sc.next();
 		System.out.println("Enter course name ");
 	   coursename=sc.next();
 	  System.out.println("Enter the startDate ");
 	  startdate=sc.next();
 	 System.out.println("Enter the endDate ");
	  enddate=sc.next();
	  System.out.println("Enter trainer rating ");
		rating=sc.nextInt();
		Trainer trainer= new Trainer(name,coursename,startdate,enddate,rating);
		service.addFeedback(trainer);
		
		maps=service.getTrainerList();
		/*System.out.println(maps);*/
		System.out.println("enter the rating to be found::");
		int n= sc.nextInt();
		for(Map.Entry<Integer, Trainer>m:maps.entrySet()){
			if(m.getValue().getRating()==n){
				System.out.println(m.getKey()+" "+m.getValue());
				
			}
		}
	  
	}

}
