package com.cg.dao;

import java.util.HashMap;

import com.cg.beans.Trainer;

public interface FeedbackDAO {

	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();
}
