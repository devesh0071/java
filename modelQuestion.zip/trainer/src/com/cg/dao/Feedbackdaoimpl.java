package com.cg.dao;

import java.util.HashMap;

import com.cg.beans.Trainer;
import com.cg.util.DBUtil;

public class Feedbackdaoimpl implements FeedbackDAO {
	

	@Override
	public void addFeedback(Trainer trainer) {
		int feedback_id=(int)(Math.random()*1000);
		DBUtil.feedbackList.put(feedback_id,trainer);
			
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		
		return DBUtil.feedbackList;
	}

}
