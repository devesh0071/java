package com.cg.service;

import java.util.HashMap;

import com.cg.beans.Trainer;
import com.cg.dao.FeedbackDAO;
import com.cg.dao.Feedbackdaoimpl;

public class Feedbackserviceimpl implements FeedbackService {
	FeedbackDAO daoRef= new Feedbackdaoimpl();
	

	@Override
	public void addFeedback(Trainer trainer) {
		daoRef.addFeedback(trainer);
		
		
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		
		return daoRef.getTrainerList();
	}

}
