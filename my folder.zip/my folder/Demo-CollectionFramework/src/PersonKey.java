
public class PersonKey implements Comparable<PersonKey>{
	private char prefix;
	private int id;
	
	
	@Override
	public int compareTo(PersonKey o) {
		
		System.out.println(this + " comapred with "+ o);
		return this.id - o.id;
	}
	
	public PersonKey() {
		//default constructor
	}
	
	public char getPrefix() {
		return prefix;
	}

	public PersonKey(char prefix, int id) {
		this.prefix = prefix;
		this.id = id;
	}
	
	@Override
	public String toString() {
		return String.valueOf(id)+getPrefix();
	}
	
	
}
