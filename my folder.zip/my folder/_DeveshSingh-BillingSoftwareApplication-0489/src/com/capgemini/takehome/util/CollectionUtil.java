package com.capgemini.takehome.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;

public class CollectionUtil {

		
		private static Map<Integer,Product> products=new HashMap<>();
			

			public CollectionUtil() {

				Product product1 = new Product();
				product1.setId(1001);
				product1.setProductName("iPhone");
				product1.setProductCategory("Electronics");
				product1.setProductPrice(35000);

				products.put(product1.getId(),product1);

				Product product2 = new Product();
				product2.setId(1002);
				product2.setProductName("LEDTV");
				product2.setProductCategory("Electronics");
				product2.setProductPrice(45000);

				products.put(product2.getId(),product2);

				Product product3 = new Product();
				product3.setId(1003);
				product3.setProductName("Teddy");
				product3.setProductCategory("Toys");
				product3.setProductPrice(800);
				
				products.put(product3.getId(),product3);

				Product product4 = new Product();
				product4.setId(1004);
				product4.setProductName("Telescope`");
				product4.setProductCategory("Toys");
				product4.setProductPrice(5000);

				products.put(product4.getId(),product4);

			}
			//products.put(1002,newProduct(1001,"iPhone","Electonics",35000));
			//products.put(1001,newProduct(1002,"LEDTV","Electonics",45000));
			//products.put(1003,newProduct(1003,"Teddy","Toys",800));
			//products.put(1004,newProduct(1001,"Telescope","Toys",5000));
			
		}
		
