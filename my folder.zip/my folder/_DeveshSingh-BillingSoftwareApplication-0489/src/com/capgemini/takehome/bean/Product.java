package com.capgemini.takehome.bean;

public class Product {

	private int id;
	private String ProductName; 
	private String ProductCategory;
	private double productPrice;
	
	public Product()
	{
		// TODO Auto-generated constructor stub
	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public String getProductCategory() {
		return ProductCategory;
	}

	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	
	public String toString()
	{
		return "["+ProductName +"-"+ ProductCategory + "-"+ productPrice+"]";
		//return "[ProductName+ProductCategory+productPrice]";
	}

}
