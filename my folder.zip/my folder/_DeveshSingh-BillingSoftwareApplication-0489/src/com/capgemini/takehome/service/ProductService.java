package com.capgemini.takehome.service;

import java.util.List;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements IProductService {
	
	private IProductDAO daoRef = new ProductDAO();
	@Override
	public List<Product> getProductDetails(int id) {
		List<Product> pro = daoRef.getProductDetails(id);
		return pro; 
	}

}
