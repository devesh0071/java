package com.capgemini.takehome.service;

import java.util.List;

import com.capgemini.takehome.bean.Product;

public interface IProductService {

	public List<Product> getProductDetails(int id);
}
