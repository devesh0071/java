package com.capgemini.takehome.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.takehome.Exception.InvalidNameException;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

//import Exception.NameNotValidException;

public class Client {

	private static Scanner sc;
	public static void main(String[] args) throws InvalidNameException {
		
		 IProductService service = new ProductService();
		 sc=new Scanner(System.in);
		 List<Product> pro = service.getProductDetails(5);
		
         System.out.println("Generate bill by entering Product code and quantity");
         System.out.println("Exit");
        
         
         int ch=sc.nextInt();
         switch(ch)
         {
         
         case 1 :  System.out.println("Enter product details");
                   System.out.println("Enter the product code");
                   int productCode=sc.nextInt();
                   System.out.println("Enter the quantity");
                   int q=sc.nextInt();
                   if(q<0)
                   {
                	   throw new InvalidNameException();
                   }
                   /*if(String(productCode.length()<4||productCode.length()>4))
                   {
                       
                	   throw new InvalidProductCode();
                	   System.out.println("Sorry!The Product Code is not available");
                	   
                   }*/
                   
                   pro = service.getProductDetails(5);
   				
   				for(Product product: pro){
   					System.out.print(product);
   				}
   				
   			break;
   			
         case 2 : System.exit(0);
			      break;
			
         default:
				System.out.println("Wrong Choice");
         
         
         
         
         
	}
	}
}

