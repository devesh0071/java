package com.capgemini.takehome.testcases;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;


public class testcase1 {

private IProductDAO daoRef;

@Before
public void setup() {
 System.out.println("setting up  dao object");
 daoRef = new ProductDAO();
}

@Test
public void test() {

	Product product1 = new Product();
	product1.setId(1001);
	product1.setProductName("iPhone");
	product1.setProductCategory("Electronics");
	product1.setProductPrice(35000);


}
@After
public void tearDown() {
 System.out.println("cleaning up dao object");
 daoRef = null;
}
}
