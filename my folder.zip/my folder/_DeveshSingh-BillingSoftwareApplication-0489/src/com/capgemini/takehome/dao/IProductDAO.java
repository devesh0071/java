package com.capgemini.takehome.dao;

import java.util.List;

import com.capgemini.takehome.bean.Product;


public interface IProductDAO {

		public List<Product> getProductDetails(int id);
	
}
