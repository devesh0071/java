package com.capgemini.takehome.Exception;

public class InvalidNameException extends Exception {

		

	}

