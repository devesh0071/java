package com.capgemini.takehome.Exception;

public class InvalidProductCode extends Exception{

	//System.out.println("Sorry!The Product Code is not available");
}
