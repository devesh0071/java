
public class Test {

	public static void main(String args[])
	{
		Teller t=new Teller(new Bank());
		t.performTransfer();
		
	}
}
