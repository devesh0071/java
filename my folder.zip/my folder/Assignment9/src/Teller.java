public class Teller {
	
	Bank b;
	public Teller(Bank b)
	{
		this.b=b;
	}

	public void performTransfer()
	{   
		//Bank b=new Bank();
		b.transferAmount(1,4,1000.0);
		b.transferAmount(1,5,5000.0);
		b.showTotalBalance();
		
		
	}
}
