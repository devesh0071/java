
public class Account {

	private int Id;
	private double Balance;
	Account[] accounts;
	
public Account(int id,double balance)
	{
		Id=id;	
		Balance=balance;
		
	}

	//accounts[5]=new Account();
	public void setId(int id) {
		Id = id;
	}
	
	public int getId() {
		return Id;
	}

	public void setBalance(double balance) {
		Balance = balance;
	}
	
	public double getBalance() {
		return Balance;
	}

	public boolean Deposit(double amount)
	{
		
		  this.Balance=this.Balance+amount;
		
		return true;
	}

	public boolean Withdrawl(double amount)
	{
	
		   this.Balance=Balance-amount;
		
		return true;
	}


}
