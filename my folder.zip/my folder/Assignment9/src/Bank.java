
public class Bank {

	//int toAccount,fromAccount;
	//double amount;
	Account accounts[]=new Account[5];
	int i;
	static double total=0;
	
	public Bank()
	{
		accounts[0]=new Account(1,1000.0);
		accounts[1]=new Account(2,2000.0);
		accounts[2]=new Account(3,5000.0);
		accounts[3]=new Account(4,3000.0);
		accounts[4]=new Account(5,7000.0);
	}
	
	void transferAmount(int toAccounts, int fromAccounts,double amount)
	{
		for(i=0;i<5;i++)
		{
			if(accounts[i].getId()==toAccounts)
				accounts[i].Deposit(amount);
			if(accounts[i].getId()==fromAccounts)
				accounts[i].Withdrawl(amount);
		}
	}
	
	void showTotalBalance()
	{
		System.out.println("1."+accounts[0].getBalance());
		System.out.println("2."+accounts[1].getBalance());
		System.out.println("3."+accounts[2].getBalance());
		System.out.println("4."+accounts[3].getBalance());
		System.out.println("5."+accounts[4].getBalance());
		
		for(i=0;i<5;i++)
		{
			total=total+accounts[i].getBalance();
		}
		
		System.out.println("Total Amount:"+total);
		
	}
	
	
}
