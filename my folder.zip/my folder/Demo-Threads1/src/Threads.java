import com.capgemini.beans.Account;

class DepositThread extends Thread {
	private Account sharedAccount;

	public DepositThread(Account sharedAccount) {
		this.sharedAccount = sharedAccount;
	}

	@Override
	public void run() {
		int token = 0;
		try {
			while (token++ < 4){
				Thread.sleep(300);
				sharedAccount.deposit(1000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}

class WithdrawThread extends Thread {

	private Account sharedAccount;

	public WithdrawThread(Account sharedAccount) {
		this.sharedAccount = sharedAccount;
	}

	@Override
	public void run() {
		int token = 0;
		try {
			while (token++ < 4){
				Thread.sleep(500);
				sharedAccount.withdraw(1000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}

class OddNumbersThread extends Thread {

	@Override
	public void run() /* throws InterruptedException */ {

		try {
			MyUtils2.printOddNos();
			MyUtils2.printEvenNos();
			;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

class EvenNumbersThread extends Thread {

	@Override
	public void run() {

		try {
			MyUtils2.printEvenNos();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		;
	}

}

class MyUtils2 {

	public static void printOddNos() throws InterruptedException {
		int count = 1;
		while (true) {
			System.out.println(count);
			Thread.sleep(800);

			count += 2;
		}
	}

	public static void printEvenNos() throws InterruptedException {
		int count = 0;
		while (true) {
			System.out.println(count);
			Thread.sleep(400);

			count += 2;
		}
	}
}
