import java.io.*;

//import com.capgemini.utils.IOUtils;

public class IOExample {

public static void main(String[] args) throws IOException {
	
	
	int t;
	char ch;
	StringBuffer dat=new StringBuffer();
	String file1=args[0];
	String file2=args[1];
	FileWriter fil=new FileWriter(file2);
	try {
		FileInputStream file=new  FileInputStream(file1);
		while(true)
		{
			t=file.read();
			if(t==-1)
			{
				break;
			}
			ch=(char)t;
			if(Character.isDigit(ch)){
				ch='*';
			}
			if (Character.isUpperCase(ch)) {
	            ch = Character.toLowerCase(ch);
	        }
			
			 
			else if((Character.isLowerCase(ch))) {
	        	ch=Character.toUpperCase(ch);
	        }
			dat=dat.append(ch);
		}
		file.close();
	}
	catch(IOException e)
	{
		System.out.println("Error in File");
	}
	fil.write(dat.toString());
	fil.close();
}
}
	
	
	/*File file1 = new File("abc.txt");
    File file2 = new File("test.txt");
    BufferedReader in = (new BufferedReader(new FileReader(file1)));
    PrintWriter out = (new PrintWriter(new FileWriter(file2)));

    int ch;
    while ((ch = in.read()) != -1) {
        if (Character.isUpperCase(ch)) {
            ch = Character.toLowerCase(ch);
        }
        
        if((Character.isLowerCase(ch))) {
        	ch=Character.toUpperCase(ch);
        }
        
        
        out.write(ch);
    }

    in.close();
    out.close();
}
}*/
	
	    