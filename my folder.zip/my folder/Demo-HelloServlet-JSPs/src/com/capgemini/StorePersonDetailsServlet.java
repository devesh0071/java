package com.capgemini;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns="/storeDetails")
public class StorePersonDetailsServlet extends HttpServlet{

	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("uname");
		int age = Integer.parseInt(request.getParameter("age"));
		String gender = request.getParameter("gender");
		
		Person personRef = new Person();
		
		personRef.setAge(age);
		personRef.setUserName(userName);
		personRef.setGender(gender);
		
		request.setAttribute("pd", personRef);
		
		RequestDispatcher dispatcher;
		
		dispatcher = request.getRequestDispatcher("displayDetails");
		dispatcher.forward(request, response);
		
	}
	
}
