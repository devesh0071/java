package com.capgemini;

public class Person {
//	DATA MEMBER
	private String uname;
	private int age;
	private String gender;
	
	public Person() {
		System.out.println("Person is instantiated");
	}
	
//	userName is a property
	public void setUserName(String uname){
		this.uname = uname;
	}
	
	
	public String getUserName(){
		return uname;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getGender() {
		return gender;
	}
	
	
	
	
	
	
}
