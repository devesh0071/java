package com.capgemini;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/displayDetails")
public class DisplayPersonDetailsServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		out.println("<HTML>");

		out.println("<head><title>");
		out.println("Registration details");
		out.println("</title></head>");

		out.println("<body>");

		Person personRef = (Person)request.getAttribute("pd");
		
		out.println("<div>");
		
		out.println(personRef.getUserName() + "<br/>");
		out.println(personRef.getAge() + "<br/>");
		out.println(personRef.getGender() + "<br/>");
		
		out.println("</div>");
		out.println("</body>");

		out.println("</HTML>");

	}
}
