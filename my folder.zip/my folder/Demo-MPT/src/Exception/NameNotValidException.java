package Exception;

public class NameNotValidException extends Exception {

}
