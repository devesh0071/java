
class Rupee extends Currency {
	public Rupee(int amt) {
		super("Rs", amt);
	}
}
