class Dollar extends Currency
	{
	public Dollar(int amt)
	{
	super("$",amt);
	}
	}