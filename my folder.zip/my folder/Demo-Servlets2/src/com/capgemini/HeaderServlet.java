package com.capgemini;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HeaderServlet extends HttpServlet{

	public HeaderServlet() {
//		System.out.println(this.getServletName() + " will be created, now");
	}
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		System.out.println(this.getServletName() + " is now configured");
		System.out.println("It belongs to "+ 
				this.getServletConfig().getServletContext().getContextPath());
		
		Enumeration<String> names =  this.getServletConfig().getInitParameterNames();
		
		while(names.hasMoreElements()){
			String initParamName = names.nextElement();
			String initParamValue = this.getServletConfig().getInitParameter(initParamName); 
			System.out.println(initParamName + ": "+ initParamValue);
		}

		names =  this.getServletConfig().
				getServletContext().getInitParameterNames();
		
		while(names.hasMoreElements()){
			String initParamName = names.nextElement();
			String initParamValue = this.getServletContext().getInitParameter(initParamName); 
			System.out.println(initParamName + ": "+ initParamValue);
		}

	}
	
	@Override
	public void destroy() {
		System.out.println(this.getServletName() + " will be destroyed, now");
	}
	
	
	protected void doGet(HttpServletRequest request,
				HttpServletResponse response) throws IOException				{

		System.out.println("Handling client request");
		PrintWriter out =  response.getWriter();
		
		out.println("<HTML>");
		
		out.println("<head><title>");
		out.println("My first web page using servlet!");
		out.println("</title></head>");

		
		out.println("<body>");
		
		out.println("<h1>");
		
		out.print(new Date());
		
		out.println("</h1>");
		
		out.println("<table border=\"1\">");
//		out.println("<table border="+ 1 +">");
		
		String headerName = null, headerValue = null;
		
		Enumeration<String> headerNames = request.getHeaderNames();
		
		while(headerNames.hasMoreElements())
		{
			headerName = headerNames.nextElement();
			headerValue = request.getHeader(headerName);
			
			out.println("<tr>");
			
			out.println("<td>");out.println(headerName);out.println("<td>");
			out.println("<td>");out.println(headerValue);out.println("<td>");
			
			out.println("</tr>");
		}
		
		out.println("</table>");
		
		
		out.println("</body>");
		
		
		out.println("</HTML>");
		
		
		
		
	}
	
}
