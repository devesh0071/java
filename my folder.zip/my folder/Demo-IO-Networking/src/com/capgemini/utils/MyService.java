 package com.capgemini.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class MyService {
	public static void main(String[] args) throws IOException  {

		int port = 8045;
		ServerSocket service = new ServerSocket(port);

		System.out.println("Waiting for connection...");

		while (true) {
			Socket clientSocket = service.accept();
			System.out.println("Connection established: " + clientSocket);

			Runnable target = new MyJob(clientSocket);
			Thread t = new Thread(target);
			
			t.start();
			        
			
		}
	}
}

class MyJob implements Runnable {

	private Socket clientSocket;

	public MyJob(Socket clientSocket) {
		this.clientSocket = clientSocket;
		
	}

	@Override
	public void run() {

		try{

			InputStream in = clientSocket.getInputStream();
			BufferedReader bReader = new BufferedReader(
						new InputStreamReader(in)
					);
			
			while(bReader.ready()){
				String message = bReader.readLine();
				if(message == null){
					break;
				}
				
				System.out.println(message);
				
			}
			
			
			OutputStream oStream = clientSocket.getOutputStream();
			
			PrintWriter out = new PrintWriter(oStream,true);
			
			out.println("HTTP/1.0 200 OK");
			out.println();
			out.println("Hello, worlds!"+ clientSocket);
			out.flush();
			clientSocket.close();
			 
		}catch(IOException e){
			e.printStackTrace();
		}
		
	}

}

// That means the client will initiate the communication by 
//sending a request (normally called an HTTP Request) and the HTTP Server 
//(or Web Server) will respond back by sending a response (usually called an HTTP Response).