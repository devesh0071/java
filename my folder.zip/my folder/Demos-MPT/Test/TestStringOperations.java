import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
//import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
//import static org.junit.Assert.fail;

import org.junit.Test;
public class TestStringOperations {
    @Test
	public void test()
	{
		//fail("Not yet implemented");
		
		String expectedMessage="Hello,World!";
		String actualMessage=new String("Hello,World!");
		
		//actualMessage=null;
		
		assertTrue(actualMessage.length()>0);
		assertEquals(expectedMessage,actualMessage);
		assertNotSame(expectedMessage,actualMessage);
	}
}
