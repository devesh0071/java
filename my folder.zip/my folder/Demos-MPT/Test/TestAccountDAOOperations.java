import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Account;
import com.capgemini.beans.Options;
import com.capgemini.dao.AccountDAO;
import com.capgemini.dao.AccountDAOImpl;

public class TestAccountDAOOperations {

	private AccountDAO daoRef;
	@Before
	public void setup() {
		System.out.println("setting up dao object");
		daoRef=new AccountDAOImpl();
	}
	
	@Test
	public void Test2() {
		
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		Account newAccount=new Account();
		
		newAccount.setId(8);
		newAccount.setBalance(5000);
		newAccount.setName("Ram");
	    boolean flag=daoRef.create(newAccount);
		assertTrue(flag);
		
	    newAccount=new Account();
		newAccount.setId(8);
		newAccount.setBalance(10000);
		newAccount.setName("Shyam");
		flag=daoRef.create(newAccount);
		assertFalse(flag);
		
		flag=daoRef.update(8, newAccount);
		assertTrue(flag);
		
		flag=daoRef.delete(8);
		assertTrue(flag);
		
		Account flags=daoRef.findById(8);
		boolean a=(flags.getName()=="Shyam");
		assertTrue(a);
}
	
	@After
	public void tearDown()
	
	{
		System.out.println("Cleaning up dao object");
		daoRef=null;
	}
	

}
