import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Account;
import com.capgemini.beans.Options;
import com.capgemini.dao.AccountDAO;
import com.capgemini.dao.AccountDAOImpl;

public class TestStringOperationsTest1 {

private AccountDAO daoRef;

@Before
public void setup() {
 System.out.println("setting up  dao object");
 daoRef = new AccountDAOImpl();
}

@Test
public void test() {

 Account newAccount = new Account();
 newAccount.setId(10);
 newAccount.setBalance(348634);
 newAccount.setName("raam");

 boolean flag = daoRef.create(newAccount);

 assertTrue(flag);

 Account newAccount1 = new Account();
 newAccount1.setId(10);
 newAccount1.setBalance(4000);
 newAccount1.setName("raam");
 boolean flag1 = daoRef.create(newAccount1);

 assertFalse(flag1);

 Account newAccount2 = new Account();
 newAccount2.setId(12);
 newAccount2.setBalance(50000);
 newAccount2.setName("ramu");
 daoRef.create(newAccount2);

 assertTrue(flag);

}

@Test
public void test2() {

 Account a = daoRef.findById(2);
 assertTrue(a.getId() == 2);

}

@Test

public void test3() {

 Account newAccount3 = new Account();
 newAccount3.setId(1);

 boolean flag = daoRef.delete(1);

 assertTrue(flag);

}

@Test
public void test4() {

 List<String> l = new ArrayList<>();
 String s1 = "Akash";
 String s2 = "Mahesh";
 String s3 = "Suhas";
 String s4 = "Suresh";
 l.add(s1);
 l.add(s2);
 l.add(s3);
 l.add(s4);
 boolean f = true;
 int index = 0;
 List<Account> sorted = daoRef.sortAccountDetails(Options.byName);

 for (Account a : sorted) {
  if (!a.getName().equals(l.get(index))) {
   f = false;
   break;
  }
  index = index + 1;
 }
 assertTrue(f);

}

@Test
public void test5() {

 List<Integer> l = new ArrayList<>();
 int s1 = 1;
 int s2 = 2;
 int s3 = 3;
 int s4 = 4;
 l.add(s1);
 l.add(s2);
 l.add(s3);
 l.add(s4);
 boolean f = true;
 int index = 0;
 List<Account> sorted = daoRef.sortAccountDetails(Options.byId);

 for (Account a : sorted) {
  if (!(a.getId() == l.get(index))) {
   f = false;
   break;
  }
  index = index + 1;
 }
 assertTrue(f);
}

@After
public void tearDown() {
 System.out.println("cleaning up dao object");
 daoRef = null;
}
}