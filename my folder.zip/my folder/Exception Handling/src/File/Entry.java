package File;

import java.io.FileInputStream;

public class Entry throws IOException {
	
	FileInputStream f=null;
	try
	{
		f=new FileInputStream("leg.text");
		while(ch)
		{
			
		}
	}
	

}
