package com.capgemini.bean;

import com.capgemini.beans.Contract_Based_Employee;
import com.capgemini.beans.Contractor;
import com.capgemini.beans.Date;
import com.capgemini.beans.Mediclaim;

public class TechnicalAssociates extends Contract_Based_Employee {
	private Mediclaim coverageAmount;

	public TechnicalAssociates(String fname,String lname,Date doj,int hours,Contractor contracto)
	{
		super(fname,lname,doj,hours,contracto);
		
	}
	
	/*public Mediclaim getMediclaim()
	{
		return new Mediclaim(this.getSalary()*1);
	}*/
	
}
