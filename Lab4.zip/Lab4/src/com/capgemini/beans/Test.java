package com.capgemini.beans;
//import com.capgemini.bean.*;

public class Test {
	
	public static void main(String args[])
	{
		//Employee p=new Permanent_Employee("Devesh","Singh",30000.0,);;
		//String dt=p.getDoj().display();
		TechnicalAssociates t=new TechnicalAssociates("Devesh","Singh",25000.0,new Date(19,03,2005));
		Date date1=new Date(25,03,2010);
		Date date2=new Date(15,03,2018);
		ProjectManager p=new ProjectManager("Rahul","Soni",45000.0,date1);
		Contractor c=new Contractor("Abhishek",5000.0);
		com.capgemini.bean.TechnicalAssociates t1=new com.capgemini.bean.TechnicalAssociates("Harsh","Jadon",date2,6,c);
		
		
		//Contract_Based_Employee emp1=new Contract_Based_Employee("Harsh","Jadon",date1,8,c);
		System.out.println("Contract Based Employee information");
		System.out.println("Employee Name :"+t1.getFname()+" "+t1.getLname());
		System.out.println("Employee Designation : Technical Associate");
		System.out.println("Employee Salary :"+t1.getSalary());
		//System.out.println("Employee Id :"+emp1.getId());
		//System.out.println("Contractor Name :"+emp1.contractor.getName());
		String dt1=t1.getDoj().display();
		System.out.println("Date of Joining :"+dt1);
		System.out.println("No. of Contract Based employees :"+Contract_Based_Employee.getcounts());
		System.out.println();
		
		System.out.println("Permanent Employee(Project Manager)");
		System.out.println("Employee Name :"+p.getFname()+" "+p.getLname());
		System.out.println("Employee Designation : Project Manager");
		System.out.println("Employee Salary :"+p.getSalary());
		//System.out.println("Employee Id :"+emp1.getId());
		//System.out.println("Contractor Name :"+emp1.contractor.getName());
		String dt2=p.getDoj().display();
		System.out.println("Date of Joining :"+dt2);
		System.out.println("Medical Coverage :"+p.getM().getCoverage());
		System.out.println();
		
		System.out.println("Permanent Employee information(Technical Associate)");
		System.out.println("Employee Name :"+t.getFname()+" "+t.getLname());
		System.out.println("Employee Designation :"+"Technical Associate");
		System.out.println("Employee Salary :"+t.getSalary());
		String dt3=t.getDoj().display();
		//System.out.println("Employee Id :"+p.getId());
		System.out.println("Date of Joining :"+dt3);
        System.out.println("Medical Coverage :"+t.getMediclaim().getCoverage());
        System.out.println("No. of Permanent employees :"+Permanent_Employee.count);
		System.out.println();
		System.out.println("Total no. of employees :"+Employee.getCount());
		
		
	}

}
