package com.capgemini.beans;

public class ProjectManager extends Permanent_Employee {

	Mediclaim m;
	public ProjectManager(String fname,String lname,double salary,Date doj)
{
	super(fname,lname,salary,doj);
	
}
	public Mediclaim getM() {
		m= new Mediclaim(this.getSalary());
		return m;
	}
	public void setM(Mediclaim m) {
		this.m = m;
	}
	



}

