package com.capgemini.beans;

public abstract class Permanent_Employee extends Employee {
	static int count=0;
	public Permanent_Employee(String fname,String lname,double salary, Date doj)
	{
		super(fname,lname,salary,doj);
		count=count+1;
		
	}
//public abstract double getMediclaim();
	

}
