package com.capgemini.beans;

public class Mediclaim  {
	
	double coverage;
	

	public Mediclaim(double coverage) {
		//super();
		this.coverage = coverage;
	}

	public double getCoverage() {
		return coverage;
	}

	public void setCoverage(double coverage) {
		this.coverage = coverage;
	}
	
	
	
	
	
	
	
	
	
	
	/*public double ProjectManager_display()
	{
		salary=(double)(100/100)*salary;
		return salary;
	}
	
	public double TechnicalAssociatee_display()
	{
		salary=(double)(200/200)*salary;
		return salary;
	}*/

}
