package com.capgemini.beans;

public abstract class Contract_Based_Employee extends Employee {

	static int counts=0;
	int hours;
	Contractor contractor;
	public  Contract_Based_Employee(String fname,String lname,Date doj,int hours,Contractor contractor)
	{
		super(fname,lname,contractor.getRate()*hours,doj);
		this.hours=hours;
		this.contractor=contractor;
		counts=counts+1;
	}
	public int getHours()
	{
		return hours;
	}
	public void setHours(int hours)
	{
		this.hours=hours;
	}
	
	public Contractor getContractor()
	{
		return contractor;
	}
	
	public void setContractor(Contractor contractor)
	{
		this.contractor=contractor;
	}
	
	public static int getcounts()
	{
		return counts;
	}
	
	//public abstract double getMediclaim();
	
	/*public String toString()
	{
		return "Contract_based_Employee[hours=" +hours +",contractor="+contractor+"]";
	}*/
}
