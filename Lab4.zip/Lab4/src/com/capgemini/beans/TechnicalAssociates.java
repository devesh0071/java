package com.capgemini.beans;
public class TechnicalAssociates extends Permanent_Employee {

	public TechnicalAssociates(String fname,String lname,double salary,Date doj)
	{
		super(fname,lname,salary,doj);
		
	}


	public Mediclaim getMediclaim()
	{
		return new Mediclaim(this.getSalary()*2);
	}
	
}
