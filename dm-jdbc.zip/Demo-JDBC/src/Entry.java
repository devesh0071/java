import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Entry {
	public static void main(String[] args) throws ClassNotFoundException, SQLException, FileNotFoundException, IOException {
		
//		TODO: Load properties into a Properties object
		Properties vendorDetails = new Properties();
		vendorDetails.load(new FileInputStream("dbVendor.properties"));
		
		
//		TODO: Register JDBC driver into Main Memory
		String driver = "";

		driver = vendorDetails.getProperty("jdbc.driver");
		Class.forName(driver);
		
//		TODO: Connect to dbms using JDBC URL
		
		String url = "";
		
		url = vendorDetails.getProperty("jdbc.url");
		Connection dbConnection;
		
		dbConnection = DriverManager.getConnection(url);
		
		System.out.println("Connection details: "+ dbConnection);
		
	}
}
