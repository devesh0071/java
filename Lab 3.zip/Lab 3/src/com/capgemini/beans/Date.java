package com.capgemini.beans;

public class Date {

	int day;
	int month;
	int year;
	public Date(int day,int month,int year)
	{
		this.day=day;
		this.month=month;
		this.year=year;
		
	}
	 String display()
	{
		return Integer.toString(this.day)+"/"+Integer.toString(this.month)+"/"+Integer.toString(this.year);
		
	}
}
