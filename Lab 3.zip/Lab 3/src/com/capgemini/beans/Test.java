package com.capgemini.beans;

public class Test {
	
	public static void main(String args[])
	{
		Employee p=new Permanent_Employee("Devesh","Singh",30000.0,new Date(15,03,2005));;
		String dt=p.getDoj().display();
		
		Date date1=new Date(25,03,2018);
		Contractor c=new Contractor("Abhishek",500.0);
		
		Contract_Based_Employee emp1=new Contract_Based_Employee("Harsh","Jadon",date1,8,c);
		System.out.println("Contract Based Employee information");
		System.out.println("Employee Name :"+emp1.getFname()+" "+emp1.getLname());
		System.out.println("Employee Salary :"+emp1.getSalary());
		System.out.println("Employee Id :"+emp1.getId());
		System.out.println("Contractor Name :"+emp1.contractor.getName());
		String jd=emp1.getDoj().display();
		System.out.println("Date of Joining :"+jd);
		System.out.println("No. of Contract Based employees :"+emp1.getcounts());
		System.out.println();
		System.out.println("Permanent Based Employee information");
		System.out.println("Employee Name :"+p.getFname()+" "+p.getLname());
		System.out.println("Employee Salary :"+p.getSalary());
		System.out.println("Employee Id :"+p.getId());
		System.out.println("Date of Joining :"+dt);
		System.out.println("No. of Permanent employees :"+Permanent_Employee.count);
		System.out.println();
		System.out.println("Total no. of employees :"+Employee.getCount());
		
	}

}
