package com.capgemini.exception;

public class ProductCodeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
