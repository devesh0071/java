package com.capgemini.takehome.dao;

import com.capgemini.takehome.ui.Product;

public interface IProductDAO {
	Product getProductDetails(int productCode);

}
