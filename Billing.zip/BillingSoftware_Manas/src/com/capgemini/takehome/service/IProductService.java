package com.capgemini.takehome.service;

import com.capgemini.takehome.ui.Product;

public interface IProductService {
	Product getProductDetails(int productCode);

}
