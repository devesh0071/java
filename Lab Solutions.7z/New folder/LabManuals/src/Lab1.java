public class Lab1 {
	
	  String FirstName;
	  String LastName;
	  float salary;
	  char Grade;
	  long id;
	  String doj;
	  static int count=0;

		public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public char getGrade() {
		return Grade;
	}
	public void setGrade(char grade) {
		Grade = grade;
	}
	public long getId() {
		return id;
	}
	
	public String getDoj()
	{
		return doj;
	}
	
	public void setDoj(String doj)
	{
		this.doj=doj;
	}
	
	public static int getcount()
	{
		return count;
	}
	
	public Lab1(String FirstName,String LastName,float salary,char Grade,String doj)
	{
		count=count+1;
		this.FirstName=FirstName;
		this.LastName=LastName;
		this.salary=salary;
		this.Grade=Grade;
		this.id=count;
		this.doj=doj;
	}
	
	
	
}
