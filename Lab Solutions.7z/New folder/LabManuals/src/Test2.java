import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Test2 {

	public static void main(String[] args) {
		Lab1 l=new Lab1("Devesh","Singh",15000,'A',"16/01/2019");
		Lab1 l1=new Lab1("Harsh","Jadon",10000,'B',"25/02/2018");
		System.out.println("ID :"+l.getId());
		System.out.println("Salary :"+l.getSalary());
		System.out.println("First Name :"+l.getFirstName());
		System.out.println("Last Name :"+l.getLastName());
		System.out.println("Grade :"+l.getGrade());
		String sdate=l.getDoj();
		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dt=LocalDate.parse(sdate,f);
		DateTimeFormatter f1=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		sdate=f1.format(dt);
		System.out.println("date of joining :"+sdate);
		System.out.println();
		
		System.out.println("ID :"+l1.getId());
		System.out.println("Salary :"+l1.getSalary());
		System.out.println("First Name :"+l1.getFirstName());
		System.out.println("Last Name :"+l1.getLastName());
		System.out.println("Grade :"+l1.getGrade());
		String sdates=l1.getDoj();
		DateTimeFormatter f3=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dt1=LocalDate.parse(sdates,f3);
		DateTimeFormatter f2=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		sdates=f2.format(dt1);
		System.out.println("date of joining :"+sdates);
		System.out.println();
		System.out.println("No of employees: "+Lab1.getcount());
		

	}

}